
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#define SIM 1
#define NAO 0
#define SUCESSO 1
#define FRACASSO 0

typedef struct{ 
        int col;
        int lin;
	}infoList;

struct noList {
    infoList dados;
    struct noList *prox;
};

struct descList { 
    int tamInfo;
    struct noList *inicio;
};


//======================APLICACAO=====================


//======================FILA=====================
struct descList * cria(int tamInfo);
int tamanhoDaLista(struct descList *p);
int reinicia(struct descList *p);
struct descList * destroi(struct descList *p);

int insereNaPoslog(int posLog, infoList *novo, struct descList *p);
int insereNovoUltimo(infoList *reg, struct descList *p);
int insereNovoPrimeiro(infoList *reg, struct descList *p);

int buscaOultimo(infoList *reg, struct descList *p);
int buscaOprimeiro(infoList *reg, struct descList *p);
int buscaNaPoslog(int posLog, infoList *reg, struct descList *p);

int removeDaPoslog(int Poslog, infoList *reg, struct descList  *p);
int removeOultimo(infoList *reg, struct descList *p);
int removeOprimeiro(infoList *reg, struct descList *p);

int testaVazia(struct descList *p);
int inverte(struct descList *p);
struct descList * destroi(struct descList *p);











