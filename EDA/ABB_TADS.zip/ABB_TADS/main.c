#include <stdio.h>
#include "arq_interface.h"


void main(){
    ABB *arv = criaABB();


    return 0;
}