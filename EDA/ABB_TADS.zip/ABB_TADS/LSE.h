#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#define SIM 1
#define NAO 0
#define SUCESSO 1
#define FRACASSO 0


typedef struct info { 
       struct descList *pos;
		char str[50];
	}info;
			


typedef struct noLSE {
    info dados;
    noLSE *prox;
} noLSE;

typedef struct DescLSE { 
    int tamInfo;
    struct noLSE *inicio;
} DescLSE;


//======================APLICACAO=====================


//======================FILA=====================
descLSE * criaLista(int tamInfo);
int tamanhoDaLista(descLSE *p);
int reinicia( descLSE *p);
 descLSE * destroi( descLSE *p);

int insereNaPoslog(int posLog, info *novo,  descLSE *p);
int insereNovoUltimo(info *reg,  descLSE *p);
int insereNovoPrimeiro(info *reg,  descLSE *p);

int buscaOultimo(info *reg,  descLSE *p);
int buscaOprimeiro(info *reg,  descLSE *p);
int buscaNaPoslog(int posLog, info *reg,  descLSE *p);

int removeDaPoslog(int Poslog, info *reg,  descLSE  *p);
int removeOultimo(info *reg,  descLSE *p);
int removeOprimeiro(info *reg,  descLSE *p);

int testaVazia( descLSE *p);
int inverte( descLSE *p);
 descLSE * destroi( descLSE *p);











