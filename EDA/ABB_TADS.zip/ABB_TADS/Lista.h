
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#define SIM 1
#define NAO 0
#define SUCESSO 1
#define FRACASSO 0

typedef struct{ 
        int col;
        int lin;
	}infoList;

struct noList {
    infoList dados;
    struct noList *prox;
};

struct DescListaPos { 
    int tamInfo;
    struct noList *inicio;
} DescListaPos;


//======================APLICACAO=====================


//======================FILA=====================
DescListaPos * criaListPos(int tamInfo);
int tamanhoDaLista(DescListaPos *p);
int reinicia(DescListaPos *p);
DescListaPos * destroi(DescListaPos *p);

int insereNaPoslog(int posLog, infoList *novo, DescListaPos *p);
int insereNovoUltimo(infoList *reg, DescListaPos *p);
int insereNovoPrimeiro(infoList *reg, DescListaPos *p);

int buscaOultimo(infoList *reg, DescListaPos *p);
int buscaOprimeiro(infoList *reg, DescListaPos *p);
int buscaNaPoslog(int posLog, infoList *reg, DescListaPos *p);

int removeDaPoslog(int Poslog, infoList *reg, DescListaPos  *p);
int removeOultimo(infoList *reg, DescListaPos *p);
int removeOprimeiro(infoList *reg, DescListaPos *p);

int testaVazia(DescListaPos *p);
int inverte(DescListaPos *p);
DescListaPos * destroi(DescListaPos *p);











