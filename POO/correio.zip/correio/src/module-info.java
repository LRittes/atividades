/**
 * 
 */
/**
 * @author admin
 *
 */
module correio {
	requires java.desktop;
}