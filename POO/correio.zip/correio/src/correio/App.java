package correio;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.CardLayout;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import javax.swing.JTextArea;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Dimension;
import java.awt.Rectangle;

public class App extends JFrame {

	private JPanel painel;
	private JTextField textFieldNewEmail;
	private JTextField textField_1;
	private JTextField textFieldEmailLogin;
	private JTextField textFieldPasswordLogin;
	private JTextField textFieldEmailRegister;
	private JTextField textFieldPasswordRegister;
	private JTextField textFieldDe;
	private JTextField textFieldOneEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App frame = new App();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public App() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 450);
		painel = new JPanel();
		painel.setBackground(new Color(255, 255, 255));
		painel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));

		setContentPane(painel);
		painel.setLayout(null);
		
		JPanel mainRoute = new JPanel();
		mainRoute.setBounds(0, 0, 600, 450);
		painel.add(mainRoute);
		mainRoute.setLayout(new CardLayout(0, 0));
		
		JPanel loginPage = new JPanel();
		loginPage.setBackground(new Color(255, 255, 255));
		mainRoute.add(loginPage, "name_4299642073911");
		loginPage.setLayout(null);
		
		JPanel routePage = new JPanel();
		routePage.setBounds(new Rectangle(0, 0, 600, 450));
		mainRoute.add(routePage, "name_4299633132206");
		routePage.setLayout(null);
		
		JButton btnNovoEmail = new JButton("Novo Email");
		btnNovoEmail.setForeground(Color.WHITE);
		btnNovoEmail.setFocusable(false);
		btnNovoEmail.setFocusTraversalPolicyProvider(true);
		btnNovoEmail.setBackground(new Color(47, 128, 246));
		btnNovoEmail.setBounds(10, 12, 160, 47);
		routePage.add(btnNovoEmail);
		
		JButton btnCaixaDeEntrada = new JButton("Caixa de Entrada");
		btnCaixaDeEntrada.setForeground(new Color(46, 52, 54));
		btnCaixaDeEntrada.setFocusable(false);
		btnCaixaDeEntrada.setFocusTraversalPolicyProvider(true);
		btnCaixaDeEntrada.setBackground(new Color(203, 203, 203));
		btnCaixaDeEntrada.setBounds(10, 71, 160, 47);
		routePage.add(btnCaixaDeEntrada);
		
		JPanel viewRoute = new JPanel();
		viewRoute.setBounds(193, 0, 395, 395);
		routePage.add(viewRoute);
		viewRoute.setLayout(new CardLayout(0, 0));
		
		
		
		JPanel newEmailPage = new JPanel();
		viewRoute.add(newEmailPage, "name_887989786040");
		newEmailPage.setLayout(null);
		
		JPanel emailField = new JPanel();
		emailField.setBounds(12, 12, 371, 49);
		emailField.setBackground(new Color(255, 255, 255));
		newEmailPage.add(emailField);
		emailField.setLayout(null);
		
		JLabel lblPara = new JLabel("Para:");
		lblPara.setBounds(12, 18, 38, 15);
		emailField.add(lblPara);
		
		textFieldNewEmail = new JTextField();
		textFieldNewEmail.setForeground(new Color(0, 0, 0));
		textFieldNewEmail.setBounds(55, 12, 304, 27);
		emailField.add(textFieldNewEmail);
		textFieldNewEmail.setColumns(10);
		
		JPanel subjectField = new JPanel();
		subjectField.setBounds(12, 73, 371, 49);
		subjectField.setLayout(null);
		subjectField.setBackground(Color.WHITE);
		newEmailPage.add(subjectField);
		
		JLabel lblAssunto = new JLabel("Assunto:");
		lblAssunto.setBounds(12, 18, 73, 15);
		subjectField.add(lblAssunto);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.WHITE);
		textField_1.setColumns(10);
		textField_1.setBounds(81, 12, 273, 27);
		subjectField.add(textField_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(12, 134, 371, 209);
		newEmailPage.add(textArea);
		
		JButton btnSendEmail = new JButton("Enviar");
		btnSendEmail.setForeground(new Color(255, 255, 255));
		btnSendEmail.setBackground(new Color(94, 195, 60));
		btnSendEmail.setBounds(266, 355, 117, 25);
		newEmailPage.add(btnSendEmail);
		
		JPanel inboxPage = new JPanel();
		viewRoute.add(inboxPage, "name_888002535061");
		inboxPage.setLayout(null);
		
		JPanel emailCardInboxPage = new JPanel();
		emailCardInboxPage.setBounds(12, 12, 373, 43);
		emailCardInboxPage.setBackground(new Color(203, 203, 203));
		inboxPage.add(emailCardInboxPage);
		emailCardInboxPage.setLayout(null);
		
		JLabel lblUserNameInboxPage = new JLabel("userName");
		lblUserNameInboxPage.setBounds(12, 12, 72, 15);
		emailCardInboxPage.add(lblUserNameInboxPage);
		
		JLabel lblSubjectInboxPage = new JLabel("Subject");
		lblSubjectInboxPage.setBounds(142, 12, 70, 15);
		emailCardInboxPage.add(lblSubjectInboxPage);
		
		JButton btnDel = new JButton("del");
		btnDel.setForeground(new Color(243, 243, 243));
		btnDel.setBackground(new Color(249, 107, 107));
		btnDel.setMargin(new Insets(2, 2, 2, 2));
		btnDel.setFont(new Font("Dialog", Font.PLAIN, 8));
		btnDel.setBounds(319, 2, 25, 25);
		emailCardInboxPage.add(btnDel);
		
		JPanel responderEmailPage = new JPanel();
		responderEmailPage.setLayout(null);
		viewRoute.add(responderEmailPage, "name_1682630940146");
		
		JPanel emailFieldDe = new JPanel();
		emailFieldDe.setLayout(null);
		emailFieldDe.setBackground(Color.WHITE);
		emailFieldDe.setBounds(12, 12, 371, 49);
		responderEmailPage.add(emailFieldDe);
		
		JLabel lblDe = new JLabel("De:");
		lblDe.setBounds(12, 18, 38, 15);
		emailFieldDe.add(lblDe);
		
		textFieldDe = new JTextField();
		textFieldDe.setForeground(Color.BLACK);
		textFieldDe.setColumns(10);
		textFieldDe.setBounds(55, 12, 304, 27);
		emailFieldDe.add(textFieldDe);
		
		JPanel subjectFieldOneEmail = new JPanel();
		subjectFieldOneEmail.setLayout(null);
		subjectFieldOneEmail.setBackground(Color.WHITE);
		subjectFieldOneEmail.setBounds(12, 73, 371, 49);
		responderEmailPage.add(subjectFieldOneEmail);
		
		JLabel lblAssuntoOneEmail = new JLabel("Assunto:");
		lblAssuntoOneEmail.setBounds(12, 18, 73, 15);
		subjectFieldOneEmail.add(lblAssuntoOneEmail);
		
		textFieldOneEmail = new JTextField();
		textFieldOneEmail.setForeground(Color.WHITE);
		textFieldOneEmail.setColumns(10);
		textFieldOneEmail.setBounds(81, 12, 273, 27);
		subjectFieldOneEmail.add(textFieldOneEmail);
		
		JTextArea textAreaOneEmail = new JTextArea();
		textAreaOneEmail.setBounds(12, 134, 371, 209);
		responderEmailPage.add(textAreaOneEmail);
		
		JButton btnResponderEmail = new JButton("Responder Email");
		btnResponderEmail.setForeground(Color.WHITE);
		btnResponderEmail.setBackground(new Color(94, 195, 60));
		btnResponderEmail.setBounds(182, 355, 201, 25);
		responderEmailPage.add(btnResponderEmail);
		
		
		
		JLabel lblNoMembro = new JLabel("Não é membro ?");
		lblNoMembro.setBounds(211, 316, 84, 25);
		loginPage.add(lblNoMembro);
		lblNoMembro.setFont(new Font("Dialog", Font.BOLD, 8));
		
		JButton btnToCadastrarPage = new JButton("Se cadastre aqui");
		btnToCadastrarPage.setBounds(293, 316, 110, 25);
		loginPage.add(btnToCadastrarPage);
		btnToCadastrarPage.setBorderPainted(false);
		btnToCadastrarPage.setBackground(new Color(255, 255, 255));
		btnToCadastrarPage.setForeground(new Color(47, 128, 246));
		btnToCadastrarPage.setFont(new Font("Dialog", Font.BOLD, 8));
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.setBounds(222, 257, 160, 47);
		loginPage.add(btnEntrar);
		btnEntrar.setForeground(new Color(255, 255, 255));
		btnEntrar.setFocusable(false);
		btnEntrar.setFocusTraversalPolicyProvider(true);
		btnEntrar.setBackground(new Color(47, 128, 246));
		
		JLabel lblPasswordLogin = new JLabel("Senha:");
		lblPasswordLogin.setBounds(138, 206, 51, 25);
		loginPage.add(lblPasswordLogin);
		
		textFieldEmailLogin = new JTextField();
		textFieldEmailLogin.setBounds(138, 169, 314, 25);
		loginPage.add(textFieldEmailLogin);
		textFieldEmailLogin.setColumns(10);
		
		JLabel lblEmailLogin = new JLabel("Email:");
		lblEmailLogin.setBounds(138, 135, 51, 25);
		loginPage.add(lblEmailLogin);
		
		JLabel lblLogin = new JLabel("LOGIN");
		lblLogin.setBounds(222, 37, 181, 95);
		loginPage.add(lblLogin);
		lblLogin.setFont(new Font("Garuda", Font.PLAIN, 50));
		lblLogin.setMaximumSize(new Dimension(100, 50));
		lblLogin.setMinimumSize(new Dimension(100, 50));
		
		textFieldPasswordLogin = new JTextField();
		textFieldPasswordLogin.setColumns(10);
		textFieldPasswordLogin.setBounds(138, 227, 314, 25);
		loginPage.add(textFieldPasswordLogin);
		
		JPanel registerPage = new JPanel();
		registerPage.setLayout(null);
		registerPage.setBackground(Color.WHITE);
		mainRoute.add(registerPage, "name_7130036103286");
		
		JLabel lblJaMembro = new JLabel("Já é membro ?");
		lblJaMembro.setFont(new Font("Dialog", Font.BOLD, 8));
		lblJaMembro.setBounds(211, 316, 84, 25);
		registerPage.add(lblJaMembro);
		
		JButton btnToLoginPage = new JButton("Fazer login aqui");
		btnToLoginPage.setForeground(new Color(47, 128, 246));
		btnToLoginPage.setFont(new Font("Dialog", Font.BOLD, 8));
		btnToLoginPage.setBorderPainted(false);
		btnToLoginPage.setBackground(Color.WHITE);
		btnToLoginPage.setBounds(266, 316, 110, 25);
		registerPage.add(btnToLoginPage);
		
		JButton btnRegister = new JButton("Cadastrar");
		btnRegister.setForeground(Color.WHITE);
		btnRegister.setFocusable(false);
		btnRegister.setBackground(new Color(47, 128, 246));
		btnRegister.setBounds(222, 257, 160, 47);
		registerPage.add(btnRegister);
		
		JLabel lblpasswordLogin_1 = new JLabel("Senha:");
		lblpasswordLogin_1.setBounds(138, 206, 51, 25);
		registerPage.add(lblpasswordLogin_1);
		
		textFieldEmailRegister = new JTextField();
		textFieldEmailRegister.setColumns(10);
		textFieldEmailRegister.setBounds(138, 169, 314, 25);
		registerPage.add(textFieldEmailRegister);
		
		JLabel lblemailRegister = new JLabel("Email:");
		lblemailRegister.setBounds(138, 135, 51, 25);
		registerPage.add(lblemailRegister);
		
		JLabel lblCadastrar = new JLabel("CADASTRAR");
		lblCadastrar.setMinimumSize(new Dimension(100, 50));
		lblCadastrar.setMaximumSize(new Dimension(100, 50));
		lblCadastrar.setFont(new Font("Garuda", Font.PLAIN, 50));
		lblCadastrar.setBounds(138, 34, 339, 95);
		registerPage.add(lblCadastrar);
		
		textFieldPasswordRegister = new JTextField();
		textFieldPasswordRegister.setColumns(10);
		textFieldPasswordRegister.setBounds(138, 227, 314, 25);
		registerPage.add(textFieldPasswordRegister);
		
		// Ação Botão Entrar no Login Page
		btnEntrar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						loginPage.removeAll();
						loginPage.repaint();
						loginPage.revalidate();
						loginPage.add(registerPage);
						loginPage.repaint();
						loginPage.revalidate();
					}
				});
	}
}