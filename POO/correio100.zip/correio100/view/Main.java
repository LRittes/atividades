package view;

public class Main {

	public static void main(String[] args) {

		try {
			App frame = new App();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
