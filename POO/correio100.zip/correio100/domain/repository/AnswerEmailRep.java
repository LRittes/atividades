package domain.repository;

import domain.entity.Email;

public interface AnswerEmailRep {
    public void answerEmail(Email email) throws Exception;
}
