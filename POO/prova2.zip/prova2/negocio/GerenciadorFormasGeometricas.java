package negocio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import dados.Circulo;
import dados.FormaGeometrica;
import dados.Quadrado;
import dados.Retangulo;
import dados.TrianguloEquilatero;

public class GerenciadorFormasGeometricas {
    private List<FormaGeometrica> listaForm = new ArrayList<>();

    public List<FormaGeometrica> getListaForm() {
        return listaForm;
    }

    public void addForms(FormaGeometrica f) {
        listaForm.add(f);
    }

    public void leTexto(String path) {
        FileReader reader;
        BufferedReader lerArq;

        try {
            reader = new FileReader(path);
            lerArq = new BufferedReader(reader);
            String s = lerArq.readLine();

            while (s != null) {
                String[] listStr = s.split(";");
                FormaGeometrica form = new Circulo(0, 0, 0);
                switch (listStr[0].trim()) {
                    case "Circulo":
                        form = new Circulo(Double.parseDouble(listStr[0]), Double.parseDouble(listStr[1]),
                                Double.parseDouble(listStr[2]));

                        break;
                    case "Quadrado":
                        form = new Quadrado(Double.parseDouble(listStr[0]), Double.parseDouble(listStr[1]),
                                Double.parseDouble(listStr[2]));
                        break;
                    case "TrianguloEquilatero":
                        form = new TrianguloEquilatero(Double.parseDouble(listStr[0]), Double.parseDouble(listStr[1]),
                                Double.parseDouble(listStr[2]));
                        break;
                    case "Retangulo":
                        form = new Retangulo(Double.parseDouble(listStr[0]), Double.parseDouble(listStr[1]),
                                Double.parseDouble(listStr[2]), Double.parseDouble(listStr[3]));
                        break;

                    default:
                        break;
                }
                listaForm.add(form);
                s = lerArq.readLine();
            }
            reader.close();
        } catch (Exception e) {
            System.err.print("Erro ao manipular o arquivo");
            System.exit(0);
        }
    }

    public void gravaTexto(String path, List<String> data) {
        FileWriter arq;
        try {
            arq = new FileWriter(path);
            for (int i = 0; i < data.size(); i++) {
                arq.write(data.get(i) + '\n');
            }
            arq.close();
        } catch (Exception e) {
            System.err.print("Erro ao manipular o arquivo");
            System.exit(0);
        }

    }

}
